package com.volumestyle

import android.content.Context
import android.graphics.Color

object Prefs {
    val COLORS = listOf("#FF5722", "#00BCD4", "#8BC34A", "#E91E63")

    private fun sp(c: Context) = c.getSharedPreferences("style", Context.MODE_PRIVATE)

    fun color(c: Context) = Color.parseColor(sp(c).getString("color", COLORS[0]))
    fun setColor(c: Context, hex: String) = sp(c).edit().putString("color", hex).apply()

    fun atTop(c: Context) = sp(c).getBoolean("top", true)
    fun setAtTop(c: Context, v: Boolean) = sp(c).edit().putBoolean("top", v).apply()

    fun durationMs(c: Context) = sp(c).getLong("duration", 2000L)
    fun setDuration(c: Context, v: Long) = sp(c).edit().putLong("duration", v).apply()
}
