package com.volumestyle

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (24 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(0xFF121212.toInt())
        }

        fun label(t: String, size: Float = 16f) = TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.WHITE)
            setPadding(0, pad / 2, 0, pad / 4)
        }

        root.addView(label("VolumeStyle", 28f))
        root.addView(label("1. Active le service d'accessibilité pour remplacer le panneau de volume."))
        root.addView(Button(this).apply {
            text = "Activer le service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        root.addView(label("2. Couleur de la bannière"))
        val row = LinearLayout(this).apply { gravity = Gravity.START }
        Prefs.COLORS.forEach { hex ->
            row.addView(View(this).apply {
                setBackgroundColor(Color.parseColor(hex))
                layoutParams = LinearLayout.LayoutParams((56 * d).toInt(), (56 * d).toInt()).apply {
                    marginEnd = (12 * d).toInt()
                }
                setOnClickListener { Prefs.setColor(this@MainActivity, hex) }
            })
        }
        root.addView(row)

        root.addView(label("3. Position"))
        root.addView(Switch(this).apply {
            text = "Bannière en haut"
            setTextColor(Color.WHITE)
            isChecked = Prefs.atTop(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setAtTop(this@MainActivity, v) }
        })

        root.addView(label("4. Durée d'affichage"))
        val durRow = LinearLayout(this)
        listOf(1000L to "1 s", 2000L to "2 s", 4000L to "4 s").forEach { (ms, name) ->
            durRow.addView(Button(this).apply {
                text = name
                setOnClickListener { Prefs.setDuration(this@MainActivity, ms) }
            })
        }
        root.addView(durRow)

        root.addView(label("Appuie sur les touches de volume pour tester."))
        setContentView(root)
    }
}
