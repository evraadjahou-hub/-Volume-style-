package com.volumestyle

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

class VolumeService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private val handler = Handler(Looper.getMainLooper())
    private val hideTask = Runnable { removeBanner() }

    private var banner: LinearLayout? = null
    private var bar: ProgressBar? = null
    private var icon: TextView? = null
    private var pct: TextView? = null

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val up = event.keyCode == KeyEvent.KEYCODE_VOLUME_UP
        val down = event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
        if (!up && !down) return false

        if (event.action == KeyEvent.ACTION_DOWN) {
            audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                0 // 0 = pas de panneau système
            )
            showBanner()
        }
        return true // on consomme la touche : le panneau d'origine n'apparaît plus
    }

    private fun showBanner() {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (banner == null) createBanner()
        bar?.max = max
        bar?.progress = cur
        pct?.text = "${cur * 100 / max}%"
        icon?.text = when {
            cur == 0 -> "🔇"
            cur * 2 < max -> "🔉"
            else -> "🔊"
        }
        handler.removeCallbacks(hideTask)
        handler.postDelayed(hideTask, Prefs.durationMs(this))
    }

    private fun createBanner() {
        val d = resources.displayMetrics.density
        val accent = Prefs.color(this)

        icon = TextView(this).apply { textSize = 22f }
        pct = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            minWidth = (48 * d).toInt()
            gravity = Gravity.END
        }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            layoutParams = LinearLayout.LayoutParams(0, (8 * d).toInt(), 1f).apply {
                marginStart = (12 * d).toInt()
                marginEnd = (12 * d).toInt()
            }
        }

        val bg = GradientDrawable().apply {
            cornerRadius = 32 * d
            setColor(0xE6212121.toInt())
            setStroke((2 * d).toInt(), accent)
        }
        banner = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = bg
            setPadding((20 * d).toInt(), (14 * d).toInt(), (20 * d).toInt(), (14 * d).toInt())
            addView(icon)
            addView(bar)
            addView(pct)
            alpha = 0f
        }

        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.9).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = (if (Prefs.atTop(this@VolumeService)) Gravity.TOP else Gravity.BOTTOM) or
                Gravity.CENTER_HORIZONTAL
            y = (56 * d).toInt()
        }
        wm.addView(banner, lp)
        banner?.animate()?.alpha(1f)?.setDuration(150)?.start()
    }

    private fun removeBanner() {
        banner?.let { b ->
            b.animate().alpha(0f).setDuration(200).withEndAction {
                runCatching { wm.removeView(b) }
            }.start()
        }
        banner = null; bar = null; icon = null; pct = null
    }

    override fun onDestroy() {
        handler.removeCallbacks(hideTask)
        banner?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }
}
